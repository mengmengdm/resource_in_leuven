import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UItest extends JFrame{
    private JTextField myText1;
    private JTextField myText2;
    private JButton myButton1;
    private JButton myButton2;
    private JButton showButton;
    private JButton uploadButton;
    private JLabel myLabel1;
    private JLabel myLabel2;
    private JTextField textLocation;
    private JTextField textMeasurementUnits;
    private JTextField textLastValue;
    private JTextField textMaxValue;
    private JTextField textSpecificUnit;
    private JPanel myPanel;
    private JPanel panel1;
    private JPanel panel2;
    private JPanel panel3;



    public UItest(String title){
        //generate Jframe
        super(title);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // create a JPanel
        myPanel = new JPanel();
        panel1 = new JPanel();
        panel2 = new JPanel();
        panel3 = new JPanel();
        // change the default layout to Gridlayout
        panel1.setLayout(new GridLayout(2,3));


        // create a JLabel and add some placeholder text
        myLabel1 = new JLabel();
        myLabel1.setText("???");


        myLabel2 = new JLabel();
        myLabel2.setText("???");

        // create 2 textfield and set the size to 10
        myText1 = new JTextField(20);
        myText1.setText("MeasurementUnits:hPA");
        myText2 = new JTextField(20);
        myText2.setText("please enter the unit for searching, hpa or ℃");
        textLocation = new JTextField(20);
        textMeasurementUnits = new JTextField(20);
        textLastValue = new JTextField(20);
        textMaxValue = new JTextField(20);
        textLocation.setText("please enter the Location");
        textMeasurementUnits.setText("please enter the units");
        textLastValue.setText("please enter the lastvalue");
        textMaxValue.setText("please enter the maxvalue");

        textSpecificUnit = new JTextField("please enter the unit you want to search");


        //create 2 button
        myButton1 = new JButton();
        myButton2 = new JButton();
        uploadButton = new JButton();
        uploadButton.setText("insert");
        showButton = new JButton("show all data of this specific unit");


        //set text for button
        myButton1.setText("find the location having the highest value");
        myButton2.setText("find the location having the highest value");

        //configure the actionlistener for the button
        myButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                    String url = "https://studev.groept.be/api/a23ib2c03/task2Ryan";
                    DBTest content = new DBTest();
                    try {
                        JSONArray array = new JSONArray(content.makeGETRequest(url));
                        for (int i = 0; i < array.length(); i++)
                        {
                            JSONObject curObject = array.getJSONObject(i);
                            myLabel1.setText(curObject.getString("Location"));
                        }
                    }
                    catch (JSONException e){
                        e.printStackTrace();
                    }
                };

            });

        //configure the actionlistener for the button
        myButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String url = "https://studev.groept.be/api/a23ib2c03/task3Ryan/";
                DBTest content = new DBTest();
                try {
                    String unit = myText2.getText();
                    if (!unit.equals("℃") && !unit.equals("hpa") && !unit.equals("hPa")) {
                        myLabel2.setText("currently only support to search hpa or ℃");
                        return;
                    }

                    if (unit.equals("℃")) {
                        unit = "℃";
                    } else if (unit.equals("hPa") || unit.equals("hpa")) {
                        unit = "hPa";
                    }

                    JSONArray array = new JSONArray(content.makeGETRequest(url+unit));
                    for (int i = 0; i < array.length(); i++)
                    {
                        JSONObject curObject = array.getJSONObject(i);
                        myLabel2.setText(curObject.getString("Location"));
                    }
                }
                catch (JSONException e){
                    e.printStackTrace();
                }
            };
        });

        uploadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {


                DBTest content = new DBTest();
                try {
                    String location = textLocation.getText();
                    String unit = textMeasurementUnits.getText();
                    String lastvalue = textLastValue.getText();
                    String maxvalue = textMaxValue.getText();
                    String url = "https://studev.groept.be/api/a23ib2c03/task4Ryan/"+location+"/"+unit+"/"+lastvalue+"/"+maxvalue;

                    JSONArray array = new JSONArray(content.makeGETRequest(url));

                    JOptionPane.showMessageDialog(null, "new data has been inserted", "success", JOptionPane.INFORMATION_MESSAGE);
                }
                catch (JSONException e){
                    JOptionPane.showMessageDialog(null, "please use the right form", "error", JOptionPane.INFORMATION_MESSAGE);
                    e.printStackTrace();
                }
            };
        });

        showButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                DBTest content = new DBTest();
                try {
                    String unit = textSpecificUnit.getText();
                    String url = "https://studev.groept.be/api/a23ib2c03/selectspecificRyan/"+unit;
                    JSONArray array = new JSONArray(content.makeGETRequest(url));
                    String message = "";
                    String location = "";
                    String lastvalue = "";
                    String maxvalue = "";
                    for (int i = 0; i < array.length(); i++)
                    {
                        JSONObject curObject = array.getJSONObject(i);
                        location = curObject.getString("Location");
                        lastvalue = Integer.toString(curObject.getInt("LastValue"));
                        maxvalue = Integer.toString(curObject.getInt("Max_Value"));
                        message = message+ location + " has maxvalue of"+maxvalue+unit+", and its lastvalue is"+lastvalue+unit+"\n";
                    }
                    JOptionPane.showMessageDialog(null, message, "success", JOptionPane.INFORMATION_MESSAGE);

                }
                catch (JSONException e){
                    JOptionPane.showMessageDialog(null, "no corresponding unit", "error", JOptionPane.INFORMATION_MESSAGE);
                    e.printStackTrace();
                }
            };
        });

        panel1.add(myLabel1);
        panel1.add(myText1);
        panel1.add(myButton1);
        panel1.add(myLabel2);
        panel1.add(myText2);
        panel1.add(myButton2);

        panel2.add(textLocation);
        panel2.add(textMeasurementUnits);
        panel2.add(textLastValue);
        panel2.add(textMaxValue);
        panel2.add(uploadButton);

        panel3.add(textSpecificUnit);
        panel3.add(showButton);

        myPanel.add(panel1);
        myPanel.add(panel2);
        myPanel.add(panel3);

        //add the Jpanel to the Jframe
        this.setContentPane(myPanel);

    }


    //Code always starts running at main
    public static void main(String[] args) {
        //generate my UI
        //JFrame ui= new TestUIInCode("Mytitle");

        //task1: change the title of the JFrame to your name and last name.
        JFrame ui= new UItest("HaoranFang");
        //the frame needs to become visible
        ui.setVisible(true);
        ui.setSize(1000,300);
    }


}
